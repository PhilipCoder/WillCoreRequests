﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CodeBuilder.Attributes
{
    public class ExcludeFromAPIContract : Attribute
    {
    }
}
