﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TestWeb.Models;

namespace TestWeb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PersonController : ControllerBase
    {
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Person>>> Get()
        {
            return new Person[] { new Person() {
                DateOfBirth = DateTime.Now,
                Id = Guid.NewGuid(),
                Name = "Lol Me",
                Surname = "Schoeman",
                Receipts = new List<Receipt>()
            } };
        }

        [HttpGet("{id}")]
        public ActionResult<Person> Get(int id)
        {
            return new Person();
        }

        [HttpGet("{personid}/{receiptid}")]
        public async Task<Receipt> Get(int personid, int receiptid)
        {
            return new Receipt();
        }

        [HttpPost]
        public ActionResult<bool> Post([FromBody] Person value)
        {
            return true;
        }

        [HttpPut("{id}")]
        public async Task<string> Put(int id, [FromBody] Person value)
        {
            return "success";
        }

        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}