﻿import { PersonRequestContainer } from "./js/Person.js";

(async () => {
    var personRequests = new PersonRequestContainer("http://localhost:53964");
    var person = await personRequests.Get();
})();