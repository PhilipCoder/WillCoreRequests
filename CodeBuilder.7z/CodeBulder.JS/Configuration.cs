﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CodeBulder.JS
{
    public static class Configuration
    {
        public static String ModelsFolder = "models";
        public static String OutputDirectory = "wwwroot\\js";
    }
}
