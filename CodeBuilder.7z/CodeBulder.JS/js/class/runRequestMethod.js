﻿    << method[comment] >>
    async << method[name] >> (<< method[parameters] >>){
        return this._<< method[name] >>.ExecuteRequest({<< method[requestObj] >>}, globalTokens);
    }
