﻿        << property[comment] >>
        this.<< property[name] >> = << property[assignable] >>;