﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CodeBulder.JS.Types
{
    public enum JSTypes
    {
        Array,
        Number,
        String,
        Object,
        Class,
        Date
    }
}
