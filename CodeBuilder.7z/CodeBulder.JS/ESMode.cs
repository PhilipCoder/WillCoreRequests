﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CodeBulder.JS
{
    public enum ESMode
    {
        ES6,
        ES5
    }
}
