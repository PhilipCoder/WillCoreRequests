﻿using CodeBulder.IBuilder;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;

namespace CodeBulder.JS.Builder
{
    public class JSClassContext<T>
    {
        public List<IJSClass> Classes { get; set; }
        public JSClassContext(JSClassContainer<T> container)
        {
            Classes = new List<IJSClass>();
            foreach (var classDef in container.Classes)
            {
                var newClass = JSBuilderIOCContainer.Instance.CreateJSClassFromStructure(classDef);
                Classes.Add(newClass);
                var result = newClass.GetText();
                var outputDir = Path.Combine(Directory.GetCurrentDirectory(), Configuration.OutputDirectory);
                Directory.CreateDirectory(outputDir);
                File.WriteAllText(Path.Combine(outputDir, classDef.Name+".js"), result);
                Debug.WriteLine(result);
            }
            foreach (var model in container.Models.Values)
            {
                var newClass = JSBuilderIOCContainer.Instance.CreateJSClassFromTypeStructure(model);
                var result = newClass.GetText();
                var outputDir = Path.Combine(Directory.GetCurrentDirectory(), Configuration.OutputDirectory, Configuration.ModelsFolder);
                Directory.CreateDirectory(outputDir);
                File.WriteAllText(Path.Combine(outputDir, model.TypeName+".js"), result);
                Debug.WriteLine(result);
            }
            foreach (var filePath in container.AdditionalFiles.Keys)
            {
                var outputDir = Path.Combine(Directory.GetCurrentDirectory(), Configuration.OutputDirectory, filePath);
                Directory.CreateDirectory(Path.GetDirectoryName(outputDir));
                File.WriteAllText(outputDir,container.AdditionalFiles[filePath]);
            }
        }
    }
}
